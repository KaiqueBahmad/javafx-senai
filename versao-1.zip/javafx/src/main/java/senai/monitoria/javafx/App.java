package senai.monitoria.javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * JavaFX App
 */
public class App extends Application {

//    Menu Principal pra levar a gente pras outras telas
//    - Ver as Rifas (Tem que ter botão de sortear)
//    - Comprar uma Rifa
//    - Reembolsar rifa
    
    private static Scene scene;
    public static String[][] nomes;
    
    @Override
    public void start(Stage stage) throws IOException {
        nomes = new String[3][3];
        String[] linha1 = {"nome 1", "nome 2", "nome 3"};
        nomes[0] = linha1;
        
        String[] linha2 = {"nome 4", "nome 5", "nome 6"};
        nomes[1] = linha2;
        
        String[] linha3 = {"nome 7", "nome 8", "nome 9"};
        nomes[2] = linha3;
        
        scene = new Scene(loadFXML("views/tabela"), 640, 480);
        stage.setScene(scene);
        stage.show();
        
    }

    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}